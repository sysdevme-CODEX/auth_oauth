on the OAuth provider configureation page need to be added fields:

x_studio_redirect_url
x_studio_client_secret
x_studio_token_url

other files pathced already